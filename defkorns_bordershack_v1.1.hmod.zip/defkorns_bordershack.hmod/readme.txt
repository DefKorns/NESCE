# 
# DefKorns Desktop Hack - v1.1 Feb 05, 2018
#
# Revisioned and improved by DanTheMan827
# Special thanks to KMFDManic for putting up with me and u/Pretendtious for testing.

Custom Backgrounds

Install Hmod and add your background folders to USB:\hakchi\backgrounds

Keep in mind that all background folders in USB:\hakchi\backgrounds must start with numbers, as the files.

MAX 60 BACKGROUNDS: more will lead to booting issues + C8

Set your background globally