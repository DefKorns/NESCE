Custom Backgrounds

Install Hmod and add your background folders to USB:\hakchi\backgrounds

Keep in mind that all background folders in USB:\hakchi\backgrounds must start with numbers, as the files.

MAX 65 BACKGROUNDS: more will lead to booting issues + C8

Set you background globally
