+=====================================+
 ANIMATED BOOT INTRO DEFKORNS VIDEO
+=====================================+
Script by viral_dna (a.k.a DNA64) & SwingFlip
with Special Thanks to MadMonkey!

Video by DefKorns

This .hmod installs an animated boot splash which will appear in full screen when the system boots up. A future version will include support for videos with embedded audio. This is a pre-release test build!


https://www.reddit.com/r/miniSNESmods/

Video Changelog:

v0.2 - February 1st, 2018
Set FPS to 29.970
Removed fade to black

v0.1 - January 31th, 2018
Release

Script Changelog:

v0.1 - January 31th, 2018
Pre-Release

- DNA64 (aka viral_dna)
http://classicmods.net/repo
