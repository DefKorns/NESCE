---
Name: Theme RandomizR
Creator: DefKorns
Category: _UI
Version: v0.86.2
---
### Description

**NAND**

- Add your themes to `Theme_randomizR.hmod\usr\share\themes`.
- Install Hmod


**USB/SD**

- Install Hmod
- Add your themes folders to `MEDIA:\hakchi\themes`.

**MAX 60 Themes** more will lead to booting issues + **C8**


### Credits and Thanks
- Advokaten (Swedish Police)
- CompCom (Code Revisor/Improver from the future)
- DanTheMan827 (Code Revisor/Improver)
- DefKorns (Developer)
- madmonkey (Code Revisor/Improver)
- Scrubmacher (Testing)
- Swingflip (Wanker)

and 
- HakchiResources Team
