       +==============================+
         DEFKORNS - RESIZE THUMBNAILS
       +==============================+

This module was based on remove_thumbnails.hmod include on hakchi2.

It allows you to change the thumbnails to 32x22, leaving
more space at the bottom of the screen. :)

 ONLY FOR SNESCE!!!

Install and synchronize games.

Enjoy!

v1.0 Feb 07, 2018
DefKorns