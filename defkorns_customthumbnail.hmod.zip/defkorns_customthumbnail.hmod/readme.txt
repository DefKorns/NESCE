    +====================================+
     DEFKORNS - CUSTOM FOLDERS THUMBNAILS
    +====================================+

This module was based on both *hmods already available
viral_dna (a.k.a DNA64) - SNES Original Boxart Patch &
DanTheMan827 - custom_boxart.hmod

 This allows you to change the thumbnails of your custom folders.
It creates a folder at /var/lib/hakchi/customfolder

Includes:

CLV-S-00001 - action-platform
CLV-S-00002 - action-puzzle/strategy
CLV-S-00003 - beat-em-up
CLV-S-00004 - platformer
CLV-S-00005 - puzzle-text
CLV-S-00006 - racing
CLV-S-00007 - rpg
CLV-S-00008 - shootemup
CLV-S-00009 - sports
CLV-S-00010 - strategy
CLV-S-00011 - wtf
CLV-S-00012 - Hacks
CLV-Z-ODIOP - random

Install and synchronize games.

Enjoy!

v1.5 Feb 06, 2018
DefKorns