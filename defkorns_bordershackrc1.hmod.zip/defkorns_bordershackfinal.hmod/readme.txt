Custom Backgrounds

Install Hmod and add your background folders to USB:\hakchi\backgrounds

Max 26 backgrounds (including the 11 included) 

Set you background globally
