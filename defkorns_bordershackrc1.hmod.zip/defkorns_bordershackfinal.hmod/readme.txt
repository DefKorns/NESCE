Custom Backgrounds

Install Hmod and add your background folders to USB:\hakchi\backgrounds

all backgrounds must start with numbering between 01 to 31, except 12, 15, 18, 19, 25, 27, 30

Set you background globally
