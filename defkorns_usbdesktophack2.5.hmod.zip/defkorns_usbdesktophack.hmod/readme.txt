    +====================================+
      DEFKORNS - ORIGINALS CUSTOM BOXART
    +====================================+

This module was based on both *hmods already available
viral_dna (a.k.a DNA64) - SNES Original Boxart Patch &
DanTheMan827 - custom_boxart.hmod

Special Thanks to therourke, bslenul and KMFDManic

 This allows you to change the box art for the "original" games.

Includes:

- 21 SNES Squared Box Art by DEFKORNS
- Fixed game sorting (SMW2 no longer stands @ the end; ignored "the" on Zelda)
- Improved arguments to fix Starfox
- USB-Host Suport
- Fixed Non USB Support
- Fixed Synching problems with dual boot

Install and synchronize games.

Enjoy!

v2.5 Jan 15, 2018
DefKorns